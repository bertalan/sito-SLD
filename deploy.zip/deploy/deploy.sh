#!/bin/bash
# ===========================================
# Script di deploy per Studio Legale D'Onofrio
# Server: Nginx + Gunicorn + PostgreSQL
# ===========================================

set -e

APP_DIR="/www/wwwroot/new.studiolegaledonofrio.it"
BRANCH="main"

echo "=========================================="
echo "Deploy Studio Legale D'Onofrio"
echo "=========================================="

# 1. Aggiorna codice
echo "[1/6] Aggiornamento codice..."
cd $APP_DIR
git fetch origin
git reset --hard origin/$BRANCH

# 2. Attiva virtualenv e installa dipendenze
echo "[2/6] Installazione dipendenze..."
source venv/bin/activate
pip install -r requirements.txt --quiet

# 3. Migrazioni database
echo "[3/6] Migrazioni database..."
python manage.py migrate --noinput

# 4. Collect static files
echo "[4/6] Collectstatic..."
python manage.py collectstatic --noinput --clear

# 5. Riavvia Gunicorn
echo "[5/6] Riavvio Gunicorn..."
sudo systemctl restart gunicornsld

# 6. Verifica stato
echo "[6/6] Verifica servizi..."
sudo systemctl status gunicornsld --no-pager -l

echo ""
echo "=========================================="
echo "Deploy completato!"
echo "=========================================="
