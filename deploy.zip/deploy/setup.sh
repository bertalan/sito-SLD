#!/bin/bash
# ===========================================
# Setup iniziale server per Studio Legale D'Onofrio
# Eseguire UNA SOLA VOLTA sul server di produzione
# ===========================================

set -e

APP_DIR="/www/wwwroot/new.studiolegaledonofrio.it"
REPO_URL="https://github.com/bertalan/sito-SLD.git"
DB_NAME="sld_db"
DB_USER="wagtail_sld"
DB_PASS="88ZFKSKFwWSRYK47"

echo "=========================================="
echo "Setup iniziale Studio Legale D'Onofrio"
echo "=========================================="

# 1. Crea database PostgreSQL
echo "[1/8] Configurazione PostgreSQL..."
sudo -u postgres psql -c "CREATE USER $DB_USER WITH PASSWORD '$DB_PASS';" || echo "Utente già esistente"
sudo -u postgres psql -c "CREATE DATABASE $DB_NAME OWNER $DB_USER;" || echo "Database già esistente"
sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE $DB_NAME TO $DB_USER;"

# 2. Clone repository (se non già fatto)
echo "[2/8] Clone/Update repository..."
cd $APP_DIR
git fetch origin || git clone $REPO_URL .
git reset --hard origin/main

# 3. Crea virtualenv
echo "[3/8] Creazione virtualenv..."
python3 -m venv venv
source venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt

# 4. Copia .env
echo "[4/8] Configurazione ambiente..."
cp deploy/env.production.example .env
echo ""
echo "⚠️  IMPORTANTE: Modifica il file .env con le tue credenziali!"
echo "   nano $APP_DIR/.env"
echo ""

# 5. Setup Django
echo "[5/8] Setup Django..."
source venv/bin/activate
python manage.py migrate
python manage.py collectstatic --noinput

# 6. Crea superuser
echo "[6/8] Creazione superuser..."
python manage.py createsuperuser

# 7. Installa servizio systemd
echo "[7/8] Installazione servizio Gunicorn..."
sudo cp deploy/sld.service /etc/systemd/system/gunicornsld.service
sudo systemctl daemon-reload
sudo systemctl enable gunicornsld
sudo systemctl start gunicornsld

# 8. Configura Nginx
echo "[8/8] Configurazione Nginx..."
sudo cp deploy/nginx-sld.conf /www/server/panel/vhost/nginx/new.studiolegaledonofrio.it.conf
sudo nginx -t && sudo systemctl reload nginx

echo ""
echo "=========================================="
echo "Setup completato!"
echo ""
echo "Prossimi passi:"
echo "1. Modifica $APP_DIR/.env con le credenziali corrette"
echo "2. Genera certificato SSL dal pannello BT o:"
echo "   sudo certbot certonly --webroot -w $APP_DIR -d new.studiolegaledonofrio.it"
echo "3. Verifica: https://new.studiolegaledonofrio.it"
echo "=========================================="
